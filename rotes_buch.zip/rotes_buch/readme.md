## Hello World Example

This is the extension from the [Hello World Tutorial](https://developer.thunderbird.net/add-ons/hello-world-add-on).
